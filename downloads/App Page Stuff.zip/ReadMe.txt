Only chang the few things that have the //by them on either side like this//
don't change anything eles or it won't look the same

Thanks for being a developer :)